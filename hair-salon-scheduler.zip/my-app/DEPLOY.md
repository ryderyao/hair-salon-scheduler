# 洗頭店排班系統 - 部署指南

## 快速開始

### 步驟 1：建立 Supabase 專案

1. 前往 [Supabase Dashboard](https://supabase.com/dashboard)
2. 點擊 "New Project"
3. 輸入專案名稱：`hair-salon-scheduler`
4. 選擇地區：`Southeast Asia (Singapore)`
5. 等待專案建立完成（約 1-2 分鐘）

### 步驟 2：設定資料庫

1. 在專案 Dashboard 中，點擊左側的 **SQL Editor**
2. 點擊 **New query**
3. 複製貼上 `supabase/schema.sql` 的內容
4. 點擊 **Run** 執行 SQL

### 步驟 3：啟用 Email 認證

1. 前往 **Authentication** > **Providers**
2. 找到 **Email** 並啟用它
3. 確認 "Confirm email" 設定為開啟或關閉（建議關閉以便快速測試）

### 步驟 4：建立店長帳號

1. 前往 **Authentication** > **Users**
2. 點擊 **Add user** 或 **Invite user**
3. 輸入店長的電子郵件和密碼
4. 記下這組帳密，這是登入系統的憑證

### 步驟 5：取得 API 金鑰

1. 前往 **Project Settings** > **API**
2. 複製以下資訊：
   - **Project URL** (例如: `https://xxxxxx.supabase.co`)
   - **anon public** API key (以 `eyJhbG` 開頭的長字串)

### 步驟 6：部署到 Vercel

#### 選項 A：使用 Vercel CLI

```bash
# 安裝 Vercel CLI
npm i -g vercel

# 登入 Vercel
vercel login

# 部署
vercel --prod
```

部署時會提示輸入環境變數：
- `NEXT_PUBLIC_SUPABASE_URL` = 你的 Supabase Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` = 你的 anon public API key

#### 選項 B：使用 Vercel Dashboard

1. 前往 [Vercel Dashboard](https://vercel.com/dashboard)
2. 點擊 **Add New Project**
3. 匯入 GitHub 儲存庫（如果已推送到 GitHub）
4. 或選擇 **Import Git Repository** > 貼上 GitHub URL
5. 在環境變數設定中新增：
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
6. 點擊 **Deploy**

### 步驟 7：完成！

部署完成後，Vercel 會提供一個網址（例如：`https://hair-salon-scheduler.vercel.app`）

使用步驟 4 建立的帳密登入系統。

---

## 功能說明

### 排班月曆 (/dashboard)
- 點擊日期格子新增排班
- 平日可選：早班 (12:00-17:00) 或晚班 (19:00-23:00)
- 假日可選：全日班 (11:30-23:30)
- 點擊已排班的項目可刪除

### 員工管理 (/employees)
- 新增/編輯員工姓名
- 停用/啟用員工
- 停用的員工不會出現在排班選項中

### 薪資計算 (/payroll)
- 選擇月份查看薪資
- 自動計算每位員工的總時數和金額
- 可匯出 CSV 檔案

---

## 班段與薪資設定

| 班段 | 時間 | 時數 | 適用日期 |
|------|------|------|----------|
| 早班 | 12:00-17:00 | 5小時 | 平日（週一~週五） |
| 晚班 | 19:00-23:00 | 4小時 | 平日（週一~週五） |
| 全日班 | 11:30-23:30 | 12小時 | 假日（週六~週日） |

- **時薪**：$200/小時

---

## 常見問題

### Q: 如何修改時薪？
A: 編輯 `src/lib/types.ts` 中的 `HOURLY_RATE` 常數，然後重新部署。

### Q: 如何修改班段時間？
A: 編輯 `src/lib/types.ts` 中的 `SHIFT_TYPES` 設定，然後重新部署。

### Q: 忘記密碼怎麼辦？
A: 在 Supabase Dashboard > Authentication > Users 中重置密碼。

---

## 技術支援

如有問題，請檢查：
1. Supabase 專案是否正常運作
2. 環境變數是否正確設定
3. 資料庫表格是否正確建立
