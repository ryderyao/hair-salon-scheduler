'use client';

import { useState, useEffect } from 'react';
import { format, parseISO, startOfMonth, endOfMonth } from 'date-fns';
import { zhTW } from 'date-fns/locale';
import { Calculator, Download, RefreshCw } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { HOURLY_RATE, type Employee, type Shift, type PayrollRecord } from '@/lib/types';
import Navigation from '@/components/Navigation';

export default function PayrollPage() {
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [payrollRecords, setPayrollRecords] = useState<PayrollRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const supabase = createClient();

  useEffect(() => {
    fetchData();
  }, [selectedMonth]);

  const fetchData = async () => {
    setLoading(true);
    
    const [employeesRes, shiftsRes, payrollRes] = await Promise.all([
      supabase.from('employees').select('*').eq('is_active', true).order('name'),
      supabase.from('shifts').select('*, employee:employees(*)')
        .gte('date', `${selectedMonth}-01`)
        .lte('date', `${selectedMonth}-31`),
      supabase.from('payroll_records').select('*, employee:employees(*)')
        .eq('month', selectedMonth),
    ]);

    if (employeesRes.data) setEmployees(employeesRes.data);
    if (shiftsRes.data) setShifts(shiftsRes.data);
    if (payrollRes.data) setPayrollRecords(payrollRes.data);
    
    setLoading(false);
  };

  const calculatePayroll = async () => {
    setGenerating(true);

    // Calculate hours per employee
    const employeeHours: Record<string, number> = {};
    
    shifts.forEach((shift) => {
      if (!employeeHours[shift.employee_id]) {
        employeeHours[shift.employee_id] = 0;
      }
      employeeHours[shift.employee_id] += shift.hours;
    });

    // Delete existing records for this month
    await supabase.from('payroll_records').delete().eq('month', selectedMonth);

    // Insert new records
    const records = Object.entries(employeeHours).map(([employeeId, hours]) => ({
      month: selectedMonth,
      employee_id: employeeId,
      total_hours: hours,
      total_amount: hours * HOURLY_RATE,
    }));

    if (records.length > 0) {
      await supabase.from('payroll_records').insert(records);
    }

    fetchData();
    setGenerating(false);
  };

  const getEmployeePayroll = (employeeId: string) => {
    return payrollRecords.find((r) => r.employee_id === employeeId);
  };

  const getEmployeeShifts = (employeeId: string) => {
    return shifts.filter((s) => s.employee_id === employeeId);
  };

  const exportCSV = () => {
    const headers = ['員工姓名', '總時數', '時薪', '總金額'];
    const rows = employees.map((emp) => {
      const record = getEmployeePayroll(emp.id);
      return [
        emp.name,
        record ? record.total_hours : 0,
        HOURLY_RATE,
        record ? record.total_amount : 0,
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map((row) => row.join(',')),
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `薪資計算_${selectedMonth}.csv`;
    link.click();
  };

  const totalHours = payrollRecords.reduce((sum, r) => sum + r.total_hours, 0);
  const totalAmount = payrollRecords.reduce((sum, r) => sum + r.total_amount, 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 sm:px-0">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 space-y-4 sm:space-y-0">
            <h2 className="text-2xl font-bold text-gray-900">薪資計算</h2>
            <div className="flex flex-wrap items-center gap-3">
              <input
                type="month"
                value={selectedMonth}
                onChange={(e) => setSelectedMonth(e.target.value)}
                className="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              />
              <button
                onClick={calculatePayroll}
                disabled={generating}
                className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${generating ? 'animate-spin' : ''}`} />
                {generating ? '計算中...' : '重新計算'}
              </button>
              <button
                onClick={exportCSV}
                disabled={payrollRecords.length === 0}
                className="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 disabled:opacity-50"
              >
                <Download className="w-4 h-4 mr-2" />
                匯出 CSV
              </button>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-blue-100 text-blue-600">
                  <Calculator className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">計算月份</p>
                  <p className="text-2xl font-bold text-gray-900">{selectedMonth}</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-green-100 text-green-600">
                  <Calculator className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">總時數</p>
                  <p className="text-2xl font-bold text-gray-900">{totalHours} 小時</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center">
                <div className="p-3 rounded-full bg-yellow-100 text-yellow-600">
                  <Calculator className="w-6 h-6" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-500">總薪資</p>
                  <p className="text-2xl font-bold text-gray-900">${totalAmount.toLocaleString()}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Payroll Table */}
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">薪資明細</h3>
            </div>
            {loading ? (
              <div className="p-8 text-center text-gray-500">載入中...</div>
            ) : employees.length === 0 ? (
              <div className="p-8 text-center text-gray-500">尚無員工資料</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        員工姓名
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        排班天數
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        總時數
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        時薪
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        總金額
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {employees.map((employee) => {
                      const record = getEmployeePayroll(employee.id);
                      const employeeShifts = getEmployeeShifts(employee.id);
                      return (
                        <tr key={employee.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {employee.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {employeeShifts.length} 天
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {record ? record.total_hours : 0} 小時
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            ${HOURLY_RATE}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            ${record ? record.total_amount.toLocaleString() : 0}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Shift Details */}
          {shifts.length > 0 && (
            <div className="mt-6 bg-white shadow rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-900">排班明細</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        日期
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        員工
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        時段
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        時數
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {shifts
                      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                      .map((shift) => (
                        <tr key={shift.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {shift.date}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {shift.employee?.name}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {shift.start_time} - {shift.end_time}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {shift.hours} 小時
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
