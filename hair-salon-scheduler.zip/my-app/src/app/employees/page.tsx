'use client';

import { useState, useEffect } from 'react';
import { Plus, Pencil, Ban, CheckCircle, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { type Employee } from '@/lib/types';
import Navigation from '@/components/Navigation';

export default function EmployeesPage() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [employeeName, setEmployeeName] = useState('');
  const supabase = createClient();

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    setLoading(true);
    const { data } = await supabase.from('employees').select('*').order('created_at', { ascending: false });
    if (data) setEmployees(data);
    setLoading(false);
  };

  const handleAdd = () => {
    setEditingEmployee(null);
    setEmployeeName('');
    setShowModal(true);
  };

  const handleEdit = (employee: Employee) => {
    setEditingEmployee(employee);
    setEmployeeName(employee.name);
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!employeeName.trim()) return;

    if (editingEmployee) {
      await supabase.from('employees').update({ name: employeeName.trim() }).eq('id', editingEmployee.id);
    } else {
      await supabase.from('employees').insert({ name: employeeName.trim() });
    }

    setShowModal(false);
    fetchEmployees();
  };

  const handleToggleActive = async (employee: Employee) => {
    await supabase.from('employees').update({ is_active: !employee.is_active }).eq('id', employee.id);
    fetchEmployees();
  };

  const activeEmployees = employees.filter((e) => e.is_active);
  const inactiveEmployees = employees.filter((e) => !e.is_active);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 sm:px-0">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">員工管理</h2>
            <button
              onClick={handleAdd}
              className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              新增員工
            </button>
          </div>

          {/* Active Employees */}
          <div className="bg-white shadow rounded-lg overflow-hidden mb-6">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">在職員工</h3>
            </div>
            {loading ? (
              <div className="p-8 text-center text-gray-500">載入中...</div>
            ) : activeEmployees.length === 0 ? (
              <div className="p-8 text-center text-gray-500">尚無在職員工</div>
            ) : (
              <ul className="divide-y divide-gray-200">
                {activeEmployees.map((employee) => (
                  <li key={employee.id} className="px-4 py-4 sm:px-6 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{employee.name}</p>
                      <p className="text-xs text-gray-500">
                        新增於 {new Date(employee.created_at).toLocaleDateString('zh-TW')}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleEdit(employee)}
                        className="p-2 text-gray-400 hover:text-blue-600"
                        title="編輯"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleToggleActive(employee)}
                        className="p-2 text-gray-400 hover:text-red-600"
                        title="停用"
                      >
                        <Ban className="w-4 h-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Inactive Employees */}
          {inactiveEmployees.length > 0 && (
            <div className="bg-white shadow rounded-lg overflow-hidden">
              <div className="px-4 py-5 sm:px-6 border-b border-gray-200">
                <h3 className="text-lg font-medium text-gray-500">已停用員工</h3>
              </div>
              <ul className="divide-y divide-gray-200">
                {inactiveEmployees.map((employee) => (
                  <li key={employee.id} className="px-4 py-4 sm:px-6 flex items-center justify-between bg-gray-50">
                    <div>
                      <p className="text-sm font-medium text-gray-500">{employee.name}</p>
                      <p className="text-xs text-gray-400">
                        新增於 {new Date(employee.created_at).toLocaleDateString('zh-TW')}
                      </p>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleEdit(employee)}
                        className="p-2 text-gray-400 hover:text-blue-600"
                        title="編輯"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleToggleActive(employee)}
                        className="p-2 text-gray-400 hover:text-green-600"
                        title="啟用"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </main>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                {editingEmployee ? '編輯員工' : '新增員工'}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  員工姓名
                </label>
                <input
                  type="text"
                  value={employeeName}
                  onChange={(e) => setEmployeeName(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="請輸入員工姓名"
                  autoFocus
                />
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  取消
                </button>
                <button
                  onClick={handleSave}
                  disabled={!employeeName.trim()}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  儲存
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
