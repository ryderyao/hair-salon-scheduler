'use client';

import { useState, useEffect } from 'react';
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  addMonths,
  subMonths,
  getDay,
  isWeekend,
  parseISO,
} from 'date-fns';
import { zhTW } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Plus, X } from 'lucide-react';
import { createClient } from '@/lib/supabase/client';
import { SHIFT_TYPES, HOURLY_RATE, type Employee, type Shift } from '@/lib/types';
import Navigation from '@/components/Navigation';

export default function DashboardPage() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [shifts, setShifts] = useState<Shift[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState('');
  const [selectedShiftType, setSelectedShiftType] = useState('');
  const supabase = createClient();

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(monthStart);
  const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
  const days = eachDayOfInterval({ start: calendarStart, end: calendarEnd });

  useEffect(() => {
    fetchData();
  }, [currentMonth]);

  const fetchData = async () => {
    setLoading(true);
    const monthStr = format(currentMonth, 'yyyy-MM');
    
    const [employeesRes, shiftsRes] = await Promise.all([
      supabase.from('employees').select('*').eq('is_active', true).order('name'),
      supabase.from('shifts').select('*, employee:employees(*)').gte('date', `${monthStr}-01`).lte('date', `${monthStr}-31`),
    ]);

    if (employeesRes.data) setEmployees(employeesRes.data);
    if (shiftsRes.data) setShifts(shiftsRes.data);
    setLoading(false);
  };

  const handlePrevMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const handleNextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  const handleDateClick = (date: Date) => {
    setSelectedDate(date);
    setSelectedEmployee('');
    setSelectedShiftType('');
    setShowModal(true);
  };

  const getShiftTypesForDate = (date: Date) => {
    return isWeekend(date) ? SHIFT_TYPES.WEEKEND : SHIFT_TYPES.WEEKDAY;
  };

  const getShiftsForDate = (date: Date) => {
    return shifts.filter((shift) => isSameDay(parseISO(shift.date), date));
  };

  const handleAddShift = async () => {
    if (!selectedDate || !selectedEmployee || !selectedShiftType) return;

    const shiftTypes = getShiftTypesForDate(selectedDate);
    let shiftConfig;
    
    if (selectedShiftType === 'FULL') {
      shiftConfig = (shiftTypes as { FULL: { start: string; end: string; hours: number; label: string } }).FULL;
    } else {
      shiftConfig = (shiftTypes as Record<string, { start: string; end: string; hours: number; label: string }>)[selectedShiftType];
    }

    const { error } = await supabase.from('shifts').insert({
      employee_id: selectedEmployee,
      date: format(selectedDate, 'yyyy-MM-dd'),
      start_time: shiftConfig.start,
      end_time: shiftConfig.end,
      hours: shiftConfig.hours,
    });

    if (!error) {
      setShowModal(false);
      fetchData();
    }
  };

  const handleDeleteShift = async (shiftId: string) => {
    const { error } = await supabase.from('shifts').delete().eq('id', shiftId);
    if (!error) {
      fetchData();
    }
  };

  const weekDays = ['一', '二', '三', '四', '五', '六', '日'];

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 sm:px-0">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-900">
              {format(currentMonth, 'yyyy年 M月', { locale: zhTW })}
            </h2>
            <div className="flex space-x-2">
              <button
                onClick={handlePrevMonth}
                className="p-2 rounded-md bg-white shadow-sm hover:bg-gray-50"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNextMonth}
                className="p-2 rounded-md bg-white shadow-sm hover:bg-gray-50"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Legend */}
          <div className="mb-4 p-4 bg-white rounded-lg shadow-sm">
            <h3 className="text-sm font-medium text-gray-700 mb-2">班段說明：</h3>
            <div className="text-sm text-gray-600 space-y-1">
              <p><span className="font-medium">平日（週一~週五）：</span>早班 12:00-17:00（5小時）、晚班 19:00-23:00（4小時）</p>
              <p><span className="font-medium">假日（週六~週日）：</span>全日班 11:30-23:30（12小時）</p>
              <p><span className="font-medium">時薪：</span>${HOURLY_RATE}/小時</p>
            </div>
          </div>

          {/* Calendar */}
          <div className="bg-white rounded-lg shadow overflow-hidden">
            {/* Weekday headers */}
            <div className="grid grid-cols-7 gap-px bg-gray-200">
              {weekDays.map((day) => (
                <div
                  key={day}
                  className="bg-gray-50 py-2 text-center text-sm font-medium text-gray-700"
                >
                  週{day}
                </div>
              ))}
            </div>

            {/* Calendar days */}
            <div className="grid grid-cols-7 gap-px bg-gray-200">
              {days.map((day, dayIdx) => {
                const dayShifts = getShiftsForDate(day);
                const isCurrentMonth = isSameMonth(day, currentMonth);
                const isToday = isSameDay(day, new Date());
                const isWeekendDay = isWeekend(day);

                return (
                  <div
                    key={day.toString()}
                    onClick={() => handleDateClick(day)}
                    className={`min-h-[100px] bg-white p-2 cursor-pointer hover:bg-gray-50 ${
                      !isCurrentMonth ? 'bg-gray-50 text-gray-400' : ''
                    } ${isToday ? 'ring-2 ring-blue-500 ring-inset' : ''}`}
                  >
                    <div className={`text-sm font-medium ${isWeekendDay ? 'text-red-600' : 'text-gray-900'}`}>
                      {format(day, 'd')}
                    </div>
                    <div className="mt-1 space-y-1">
                      {dayShifts.map((shift) => (
                        <div
                          key={shift.id}
                          className="text-xs bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded truncate"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteShift(shift.id);
                          }}
                          title={`${shift.employee?.name} ${shift.start_time}-${shift.end_time} (點擊刪除)`}
                        >
                          {shift.employee?.name} {shift.start_time}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Instructions */}
          <p className="mt-4 text-sm text-gray-500">
            點擊日期格子新增排班，點擊已排班的項目可刪除
          </p>
        </div>
      </main>

      {/* Modal */}
      {showModal && selectedDate && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">
                新增排班 - {format(selectedDate, 'yyyy/MM/dd')}
              </h3>
              <button
                onClick={() => setShowModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  選擇員工
                </label>
                <select
                  value={selectedEmployee}
                  onChange={(e) => setSelectedEmployee(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">請選擇員工</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  選擇班段
                </label>
                <select
                  value={selectedShiftType}
                  onChange={(e) => setSelectedShiftType(e.target.value)}
                  className="w-full border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="">請選擇班段</option>
                  {Object.entries(getShiftTypesForDate(selectedDate)).map(([key, config]) => (
                    <option key={key} value={key}>
                      {config.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex space-x-3 pt-4">
                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  取消
                </button>
                <button
                  onClick={handleAddShift}
                  disabled={!selectedEmployee || !selectedShiftType}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  新增
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
