export const HOURLY_RATE = 200;

export type ShiftConfig = {
  start: string;
  end: string;
  hours: number;
  label: string;
};

export type WeekdayShiftTypes = {
  MORNING: ShiftConfig;
  EVENING: ShiftConfig;
};

export type WeekendShiftTypes = {
  FULL: ShiftConfig;
};

export const SHIFT_TYPES = {
  WEEKDAY: {
    MORNING: { start: '12:00', end: '17:00', hours: 5, label: '早班 (12:00-17:00)' },
    EVENING: { start: '19:00', end: '23:00', hours: 4, label: '晚班 (19:00-23:00)' },
  },
  WEEKEND: {
    FULL: { start: '11:30', end: '23:30', hours: 12, label: '全日班 (11:30-23:30)' },
  },
} as const;

export type Employee = {
  id: string;
  name: string;
  is_active: boolean;
  created_at: string;
};

export type Shift = {
  id: string;
  employee_id: string;
  date: string;
  start_time: string;
  end_time: string;
  hours: number;
  created_at: string;
  employee?: Employee;
};

export type PayrollRecord = {
  id: string;
  month: string;
  employee_id: string;
  total_hours: number;
  total_amount: number;
  generated_at: string;
  employee?: Employee;
};
