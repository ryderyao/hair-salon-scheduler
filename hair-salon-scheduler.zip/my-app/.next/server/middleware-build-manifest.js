globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/vG7OkGshD9bfOXIJMjWUh/_buildManifest.js",
    "static/vG7OkGshD9bfOXIJMjWUh/_ssgManifest.js",
    "static/vG7OkGshD9bfOXIJMjWUh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0uydx4.e5a6lm.js",
    "static/chunks/09rhic1r4.0~9.js",
    "static/chunks/0ujmofs2f9xl3.js",
    "static/chunks/0l.-j3og~kl4o.js",
    "static/chunks/turbopack-10lydu3k4ch3u.js"
  ]
};
