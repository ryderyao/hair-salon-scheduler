var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/[root-of-the-server]__097gz5z._.js")
R.c("server/chunks/0umb_my-app__next-internal_server_app_favicon_ico_route_actions_0c6._n8.js")
R.m(11766)
module.exports=R.m(11766).exports
