module.exports=[68447,(a,b,c)=>{}];

//# sourceMappingURL=0umb_my-app__next-internal_server_app__global-error_page_actions_12_2-h8.js.map