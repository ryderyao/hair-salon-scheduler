module.exports=[95325,(a,b,c)=>{}];

//# sourceMappingURL=hair-salon-scheduler_my-app__next-internal_server_app_page_actions_00cffch.js.map