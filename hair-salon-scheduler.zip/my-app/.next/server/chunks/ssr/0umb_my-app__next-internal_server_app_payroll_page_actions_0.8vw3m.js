module.exports=[42565,(a,b,c)=>{}];

//# sourceMappingURL=0umb_my-app__next-internal_server_app_payroll_page_actions_0.8vw3m.js.map