module.exports=[36900,(a,b,c)=>{}];

//# sourceMappingURL=0umb_my-app__next-internal_server_app_dashboard_page_actions_0fxtzsi.js.map