module.exports=[58023,(a,b,c)=>{}];

//# sourceMappingURL=0umb_my-app__next-internal_server_app__not-found_page_actions_0wxkap0.js.map