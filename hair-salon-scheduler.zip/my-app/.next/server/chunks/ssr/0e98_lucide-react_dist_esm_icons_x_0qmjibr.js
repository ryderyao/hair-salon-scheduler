module.exports=[79590,a=>{"use strict";let b=(0,a.i(47137).default)("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);a.s(["X",0,b],79590)}];

//# sourceMappingURL=0e98_lucide-react_dist_esm_icons_x_0qmjibr.js.map