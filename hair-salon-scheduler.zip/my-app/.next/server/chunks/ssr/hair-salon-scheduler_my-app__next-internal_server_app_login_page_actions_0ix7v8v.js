module.exports=[71576,(a,b,c)=>{}];

//# sourceMappingURL=hair-salon-scheduler_my-app__next-internal_server_app_login_page_actions_0ix7v8v.js.map