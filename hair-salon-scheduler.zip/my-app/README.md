# 洗頭店排班系統

一個專為洗頭店設計的排班管理系統，支援月曆式排班、員工管理與薪資計算。

## 🚀 快速部署

### 1. 建立 Supabase 專案 (2 分鐘)

前往 [Supabase](https://supabase.com/dashboard/sign-up) 建立免費帳號並建立新專案：
- 專案名稱：`hair-salon-scheduler`
- 地區：`Southeast Asia (Singapore)`

### 2. 設定資料庫 (1 分鐘)

在 Supabase Dashboard 中：
1. 點擊左側 **SQL Editor**
2. 點擊 **New query**
3. 貼上 [schema.sql](./supabase/schema.sql) 的內容
4. 點擊 **Run**

### 3. 建立店長帳號 (1 分鐘)

1. 前往 **Authentication** > **Users**
2. 點擊 **Add user**
3. 輸入店長的電子郵件和密碼

### 4. 取得 API 金鑰 (30 秒)

前往 **Project Settings** > **API**，複製：
- **Project URL** (例如: `https://xxxxxx.supabase.co`)
- **anon public** API key

### 5. 部署到 Vercel (2 分鐘)

點擊下方按鈕一鍵部署：

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

部署時設定環境變數：
- `NEXT_PUBLIC_SUPABASE_URL` = 你的 Project URL
- `NEXT_PUBLIC_SUPABASE_ANON_KEY` = 你的 anon public API key

---

## ✨ 功能特色

- 🔐 **店長登入** - 單一帳號管理
- 📅 **月曆排班** - 直覺式點擊排班
- 👥 **員工管理** - 新增/編輯/停用員工
- 💰 **薪資計算** - 自動計算時數與金額
- 📊 **CSV 匯出** - 方便薪資發放

---

## 📋 班段設定

| 班段 | 時間 | 時數 | 適用日期 |
|------|------|------|----------|
| 早班 | 12:00-17:00 | 5小時 | 平日（週一~週五） |
| 晚班 | 19:00-23:00 | 4小時 | 平日（週一~週五） |
| 全日班 | 11:30-23:30 | 12小時 | 假日（週六~週日） |

**時薪**：$200/小時

---

## 📁 專案結構

```
my-app/
├── src/
│   ├── app/
│   │   ├── login/         # 登入頁面
│   │   ├── dashboard/     # 排班月曆
│   │   ├── employees/     # 員工管理
│   │   └── payroll/       # 薪資計算
│   ├── components/        # 共用組件
│   └── lib/
│       ├── supabase/      # Supabase 設定
│       └── types.ts       # 型別定義
├── supabase/
│   └── schema.sql         # 資料庫結構
└── README.md
```

---

## 🛠️ 本地開發

```bash
# 安裝依賴
npm install

# 設定環境變數
cp .env.local.example .env.local
# 編輯 .env.local 填入 Supabase 資訊

# 啟動開發伺服器
npm run dev
```

開啟 http://localhost:3000

---

## 📖 詳細說明

- [部署指南](./DEPLOY.md) - 完整部署步驟
- [資料庫結構](./supabase/schema.sql) - SQL 結構定義

---

## 🔧 技術棧

- [Next.js 15](https://nextjs.org/)
- [TypeScript](https://www.typescriptlang.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Supabase](https://supabase.com/)
- [date-fns](https://date-fns.org/)

---

## 📄 授權

MIT License
