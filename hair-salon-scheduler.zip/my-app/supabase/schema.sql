-- Enable RLS
alter table if exists employees enable row level security;
alter table if exists shifts enable row level security;
alter table if exists payroll_records enable row level security;

-- Create employees table
create table if not exists employees (
  id uuid default gen_random_uuid() primary key,
  name text not null,
  is_active boolean default true,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create shifts table
create table if not exists shifts (
  id uuid default gen_random_uuid() primary key,
  employee_id uuid references employees(id) on delete cascade not null,
  date date not null,
  start_time text not null,
  end_time text not null,
  hours numeric not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create payroll_records table
create table if not exists payroll_records (
  id uuid default gen_random_uuid() primary key,
  month text not null,
  employee_id uuid references employees(id) on delete cascade not null,
  total_hours numeric not null,
  total_amount numeric not null,
  generated_at timestamp with time zone default timezone('utc'::text, now()) not null,
  unique(month, employee_id)
);

-- Create RLS policies
-- Employees policies
create policy "Enable all access for authenticated users" on employees
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Shifts policies  
create policy "Enable all access for authenticated users" on shifts
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Payroll records policies
create policy "Enable all access for authenticated users" on payroll_records
  for all using (auth.role() = 'authenticated') with check (auth.role() = 'authenticated');

-- Create indexes for better performance
create index if not exists idx_shifts_date on shifts(date);
create index if not exists idx_shifts_employee_id on shifts(employee_id);
create index if not exists idx_payroll_month on payroll_records(month);
create index if not exists idx_payroll_employee_id on payroll_records(employee_id);
